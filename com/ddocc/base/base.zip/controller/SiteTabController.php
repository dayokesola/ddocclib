<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace com\ddocc\base\controller;

/**
 * Description of TabController
 *
 * @author okesolaa
 */
class SiteTabController {
    //put your code here
    public function IndexGet() {      
        $resp = array();      
        $dtos = \com\ddocc\base\service\SiteTabService::GetTabList(999);
        $resp['dtos'] = $dtos;
        return $resp;
    }
}
