<?php

namespace com\ddocc\base\service;

use com\ddocc\base\utility\Connect;
use com\ddocc\base\utility\Session;

class SystemService {

    public static function GetSettings() {
        $bank_id = Session::Get('bankid');
        $sql = " Select sys_key, sys_val from __DB__system  WHERE bank_id = :bank_id";
        $cn = new Connect();
        $cn->SetSQL($sql);
        $cn->AddParam(':bank_id', $bank_id);
        return $cn->SelectObject();
    }
    
    public static function GetSetting($k) {
        $bank_id = Session::Get('bankid');
        $sql = " Select sys_val from __DB__system  WHERE bank_id = :bank_id and sys_key = :k";
        $cn = new Connect();
        $cn->SetSQL($sql);
        $cn->AddParam(':bank_id', $bank_id);
        $cn->AddParam(':k', $k);
        return $cn->SelectScalar();
    }

}
